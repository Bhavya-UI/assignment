import React, { Component } from 'react';

class Login extends Component {
    constructor() {
        super()
        this.state = {

        };
    }

    render() {
        return (
            <div className='container-fluid pd-1 page-height' style={{ background: '#f8f9fa'}}>
                <div className='row'>
                    <div className='col-lg-4'></div>

                    <div className='col-lg-4'>
                        <h2 className='main-heading'>Log in</h2>


                        <div className="form-group">
                            <label htmlFor="exampleInputEmail1" className='mt-3 label-styling'>Email</label>
                            <input
                                type="email"
                                className="form-control mt-1"
                                placeholder='Enter your email address'

                            />
                        </div>
                        <div className="form-group mt-3">
                            <label htmlFor="exampleInputEmail1" className='label-styling' >Password</label>
                            <input
                                type="password"
                                className="form-control mt-1"
                                placeholder='Enter your password'
                            />
                        </div>
                        <div className='mt-4' style={{textAlign:'end'}}><button className='btn btn-primary'>Login</button></div>
                    </div>

                </div>
            </div>
        );
    }
}

export default Login;

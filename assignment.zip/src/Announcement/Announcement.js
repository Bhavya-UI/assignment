import React from 'react';

function Announcement() {
  return (
    <div className='bg-color' style={{ height: '83vh' }}>
      <div className='container-fluid pd-2'>
        <div className='row'>
          <div className='col-lg-9'>
            <div className='box'>
              <div className='d-flex'>
                <p className='date'>23/02/2022,</p>
                <p className='time'>08:48:15</p>
              </div>
              <p className='title'>What is Lorem Ipsum?</p>
              <div className='announcement-tag'>
                <img src="/bell.png" style={{ width: '17px', position: 'relative', top: '-2px' }} /> Announcement
              </div>
              <p className='para'>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
              <div className='mt-3 position-relative'>
                <div className="form-group">
                  <input
                    type="email"
                    className="form-control mt-1"
                    placeholder='Give us some feedback'

                  />
                  
                </div>
                <div className='position-absolute' style={{top:'6px',right:'10px'}}><img style={{width:'17px'}}src="/paper-plane.png"></img></div>
              </div>
            </div>
          </div>
          <div className='col-lg-3'>
            <button className='btn btn-primary' style={{ width: '100%' }}>Submit an announcement</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Announcement;
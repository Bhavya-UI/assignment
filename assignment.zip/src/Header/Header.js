import React from 'react';
import { Link } from "react-router-dom";
function Header() {
  return (
    <div className='container-fluid pd-2' style={{borderBottom: '2px solid #dee2e6'}}>
        <div className='row align-items-center'>
        <div className='col-lg-3 col-4' >
      <img className='logo-width' src="/skidos-logo.png"/>
      </div>
      <div className='col-lg-2 col-3'>
      <h5 className='announcement-heading'><Link className='color-black' to="/">Announcements</Link></h5>
      </div>
      <div className='col-lg-7 col-5' style={{textAlign:'end'}}>
        <button className='btn btn-primary'><Link className='color-white' to="/login">Login</Link></button>
      </div>
    </div>
    </div>
  );
}

export default Header;
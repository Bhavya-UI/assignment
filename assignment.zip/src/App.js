import logo from './logo.svg';
import './App.css';
import Header from './Header/Header';
import Login from './Login/Login';
import Announcement from './Announcement/Announcement';
import { BrowserRouter, Routes, Route } from "react-router-dom";


function App() {
  return (
    <BrowserRouter>
      <Header />
      <Routes>
        <Route exact path="/" element={<Announcement />} />
        <Route exact path="/login" element={<Login />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
